import express from "express";

const app = express();

const port = 3002;
app.listen(port, () => {

	console.log("Server is runnig on http://localhost:3002");
});